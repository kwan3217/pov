Movie consists of 10 scenes, scen0.pov to scen9.pov

run them with the following options:

  scen0: +ki0 +kf8 +kfi0 +kff99 -ul
  scen1: +ki0 +kf1 +kfi0 +kff99 -ul
scen2-8: +ki-1 +kf8 +kfi0 +kff99 -ul
  scen9: +ki0 +kf21 +kfi0 +kff99 -ul

Some bitmaps need to be converted from JPG format. If you go to something
other than TGA, the scene files will need to be changed.

I have included all files necessary to run the program. 
Some .inc files are from PovPeople, created by Hero Ngauv.

Chris Jeppesen
October 15, 1998